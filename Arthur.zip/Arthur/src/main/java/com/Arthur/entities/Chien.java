package com.Arthur.entities;


import jakarta.persistence.Entity;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor @Data
@Entity
public class Chien {
	@jakarta.persistence.Id @jakarta.persistence.GeneratedValue(strategy = jakarta.persistence.GenerationType.IDENTITY)
	private Long id;
	private String nom;
	private int age;
	private String couleur;
	private int taille;
	private boolean vendu;
	
	public Chien() {
		super();
	}
	
	
	public Chien( String nom, int age, String couleur, int taille, boolean vendu) {
		super();
		this.nom = nom;
		this.age = age;
		this.couleur = couleur;
		this.taille = taille;
		this.vendu = vendu;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getCouleur() {
		return couleur;
	}


	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}


	public int getTaille() {
		return taille;
	}


	public void setTaille(int taille) {
		this.taille = taille;
	}


	public boolean isVendu() {
		return vendu;
	}


	public void setVendu(boolean vendu) {
		this.vendu = vendu;
	}

}
