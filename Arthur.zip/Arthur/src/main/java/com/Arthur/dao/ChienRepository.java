package com.Arthur.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.Arthur.entities.Chien;

public interface ChienRepository extends CrudRepository<Chien, Long> {
	
	@Query(value = "SELECT c FROM Chien c WHERE c.nom = ?1 ")
    public Optional<Chien> findByNom(String nom);

}
