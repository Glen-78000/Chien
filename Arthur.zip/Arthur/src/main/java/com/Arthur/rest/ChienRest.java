package com.Arthur.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Arthur.dao.ChienRepository;
import com.Arthur.entities.Chien;



@RestController
@CrossOrigin("*")


public class ChienRest {

	@Autowired
	ChienRepository ChienRepo;
	
	
	@PostMapping("/addChien")
	public Chien ajouterChien(@RequestBody Chien c) {
		Chien chien = new Chien(c.getNom(), c.getAge(),c.getCouleur(),c.getTaille(),c.isVendu());
		return ChienRepo.save(chien);
	}
	
	@GetMapping("/Chien")
	public Iterable<Chien> AvoirTousChien() {

		return ChienRepo.findAll();
	}
}
